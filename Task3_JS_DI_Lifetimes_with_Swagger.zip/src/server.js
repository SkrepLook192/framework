const { createServer } = require('./app');
const port = Number(process.env.PORT || 3003);
createServer().listen(port, () => {
  console.log(`Task 3 DI lifetime demo is running: http://localhost:${port}/api/experiment`);
  console.log(`Swagger UI: http://localhost:${port}/swagger`);
});
