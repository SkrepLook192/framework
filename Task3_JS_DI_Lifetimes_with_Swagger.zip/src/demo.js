const http = require('http');
const { createServer } = require('./app');

const server = createServer();
server.listen(0, async () => {
  const port = server.address().port;
  const make = () => new Promise((resolve) => {
    http.get(`http://localhost:${port}/api/experiment`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(JSON.parse(data)));
    });
  });
  const results = await Promise.all([make(), make(), make(), make(), make()]);
  console.log(JSON.stringify(results.map(r => ({
    requestId: r.requestId,
    singletonId: r.observation.singleton.id,
    singletonValue: r.observation.singleton.valueAfterIncrement,
    scopedId: r.observation.scoped.id,
    transientDifferent: !r.observation.transient.sameInsideRequest
  })), null, 2));
  server.close();
});
