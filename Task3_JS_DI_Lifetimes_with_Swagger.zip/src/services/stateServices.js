const crypto = require('crypto');

class SingletonCounter {
  constructor() { this.id = crypto.randomUUID(); this.value = 0; }
  increment() { this.value += 1; return this.value; }
}
class TransientOperation {
  constructor() { this.id = crypto.randomUUID(); }
}
class ScopedRequestState {
  constructor() { this.id = crypto.randomUUID(); this.events = []; }
  add(event) { this.events.push(event); }
}

module.exports = { SingletonCounter, TransientOperation, ScopedRequestState };
