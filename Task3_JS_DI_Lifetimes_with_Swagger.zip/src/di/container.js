class ServiceDescriptor {
  constructor(factory, lifetime) {
    this.factory = factory;
    this.lifetime = lifetime;
    this.instance = undefined;
  }
}

class DIContainer {
  constructor(parent = null, scopedCache = null) {
    this.parent = parent;
    this.descriptors = new Map();
    this.scopedCache = scopedCache || new Map();
    this.scopeId = parent ? crypto.randomUUID() : 'root';
  }

  register(name, factory, lifetime = 'transient') {
    if (!['singleton', 'transient', 'scoped'].includes(lifetime)) {
      throw new Error(`Unknown lifetime: ${lifetime}`);
    }
    this.descriptors.set(name, new ServiceDescriptor(factory, lifetime));
  }

  createScope() {
    return new DIContainer(this, new Map());
  }

  resolve(name) {
    const owner = this.findOwner(name);
    if (!owner) {
      throw new Error(`Service not registered: ${name}`);
    }
    const descriptor = owner.descriptors.get(name);
    if (descriptor.lifetime === 'singleton') {
      if (!descriptor.instance) descriptor.instance = descriptor.factory(this);
      return descriptor.instance;
    }
    if (descriptor.lifetime === 'scoped') {
      if (!this.parent && this.scopeId === 'root') {
        throw new Error(`Cannot resolve scoped service '${name}' from root container. Create scope first.`);
      }
      if (!this.scopedCache.has(name)) this.scopedCache.set(name, descriptor.factory(this));
      return this.scopedCache.get(name);
    }
    return descriptor.factory(this);
  }

  findOwner(name) {
    if (this.descriptors.has(name)) return this;
    if (this.parent) return this.parent.findOwner(name);
    return null;
  }
}

module.exports = { DIContainer };
