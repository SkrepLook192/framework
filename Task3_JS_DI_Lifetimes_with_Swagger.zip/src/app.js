const http = require('http');
const crypto = require('crypto');
const { DIContainer } = require('./di/container');
const { SingletonCounter, TransientOperation, ScopedRequestState } = require('./services/stateServices');


function sendSwaggerUi(res) {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(`<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8" />
  <title>Практическая работа №3 — Swagger</title>
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css" />
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
  <script>
    window.onload = () => SwaggerUIBundle({ url: '/openapi.json', dom_id: '#swagger-ui' });
  </script>
</body>
</html>`);
}

function openApiDocument() {
  return {
    openapi: '3.0.3',
    info: {
      title: 'Практическая работа №3. DI lifetimes',
      version: '1.0.0',
      description: 'Демонстрация singleton, transient и scoped в собственном DI-контейнере.'
    },
    servers: [{ url: 'http://localhost:3003' }],
    paths: {
      '/api/experiment': {
        get: {
          summary: 'Запустить эксперимент по жизненным циклам DI',
          description: 'Показывает, что singleton общий, transient создаётся каждый раз, а scoped общий только внутри одного запроса.',
          responses: { 200: { description: 'Результат эксперимента' } }
        }
      },
      '/health': {
        get: {
          summary: 'Проверка живости сервиса',
          responses: { 200: { description: 'Сервис работает' } }
        }
      }
    }
  };
}

function createRootContainer() {
  const container = new DIContainer();
  container.register('singletonCounter', () => new SingletonCounter(), 'singleton');
  container.register('transientOperation', () => new TransientOperation(), 'transient');
  container.register('scopedRequestState', () => new ScopedRequestState(), 'scoped');
  return container;
}

function json(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(body, null, 2));
}

function handleRequest(rootContainer, req, res) {
  const scope = rootContainer.createScope();
  const requestId = crypto.randomUUID();
  const started = Date.now();

  const singletonA = scope.resolve('singletonCounter');
  const singletonB = scope.resolve('singletonCounter');
  const transientA = scope.resolve('transientOperation');
  const transientB = scope.resolve('transientOperation');
  const scopedA = scope.resolve('scopedRequestState');
  const scopedB = scope.resolve('scopedRequestState');

  scopedA.add(`request=${requestId}`);
  const counterValue = singletonA.increment();

  const result = {
    requestId,
    path: req.url,
    observation: {
      singleton: {
        sameInsideRequest: singletonA.id === singletonB.id,
        id: singletonA.id,
        valueAfterIncrement: counterValue,
        meaning: 'singleton общий для всех запросов, поэтому значение счётчика протекает между запросами'
      },
      transient: {
        sameInsideRequest: transientA.id === transientB.id,
        firstId: transientA.id,
        secondId: transientB.id,
        meaning: 'transient создаётся каждый раз заново'
      },
      scoped: {
        sameInsideRequest: scopedA.id === scopedB.id,
        id: scopedA.id,
        events: scopedB.events,
        meaning: 'scoped один внутри запроса, но новый для другого запроса'
      }
    },
    elapsedMs: Date.now() - started
  };

  console.log(`[${requestId}] path=${req.url} singleton=${singletonA.id} scoped=${scopedA.id} counter=${counterValue}`);
  json(res, 200, result);
}

function createServer(rootContainer = createRootContainer()) {
  return http.createServer((req, res) => {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname === '/swagger') return sendSwaggerUi(res);
    if (url.pathname === '/openapi.json') return json(res, 200, openApiDocument());
    if (url.pathname === '/' || url.pathname === '/api/experiment') return handleRequest(rootContainer, req, res);
    if (url.pathname === '/health') return json(res, 200, { status: 'ok' });
    return json(res, 404, { error: 'not_found' });
  });
}

module.exports = { createRootContainer, createServer };
