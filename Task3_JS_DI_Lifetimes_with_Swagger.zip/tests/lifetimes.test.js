const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const { createRootContainer, createServer } = require('../src/app');

test('singleton returns same instance globally', () => {
  const root = createRootContainer();
  const s1 = root.createScope();
  const s2 = root.createScope();
  assert.equal(s1.resolve('singletonCounter').id, s2.resolve('singletonCounter').id);
});

test('transient returns new instance every resolve', () => {
  const scope = createRootContainer().createScope();
  assert.notEqual(scope.resolve('transientOperation').id, scope.resolve('transientOperation').id);
});

test('scoped is same inside one scope and different between scopes', () => {
  const root = createRootContainer();
  const s1 = root.createScope();
  const s2 = root.createScope();
  assert.equal(s1.resolve('scopedRequestState').id, s1.resolve('scopedRequestState').id);
  assert.notEqual(s1.resolve('scopedRequestState').id, s2.resolve('scopedRequestState').id);
});

test('parallel requests share singleton but have different scoped states', async () => {
  const server = createServer();
  await new Promise(resolve => server.listen(0, resolve));
  const port = server.address().port;
  const call = () => new Promise((resolve) => {
    http.get(`http://localhost:${port}/api/experiment`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(JSON.parse(data)));
    });
  });
  const results = await Promise.all([call(), call(), call(), call(), call()]);
  server.close();
  const singletonIds = new Set(results.map(x => x.observation.singleton.id));
  const scopedIds = new Set(results.map(x => x.observation.scoped.id));
  assert.equal(singletonIds.size, 1);
  assert.equal(scopedIds.size, 5);
});
