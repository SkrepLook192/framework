const http = require('http');
const path = require('path');
const { PluginRegistry } = require('./core/pluginRegistry');

function json(res, statusCode, body) {
  res.writeHead(statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(body, null, 2));
}

function sendSwaggerUi(res) {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(`<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8" />
  <title>Практическая работа №4 — Swagger</title>
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css" />
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
  <script>
    window.onload = () => SwaggerUIBundle({ url: '/openapi.json', dom_id: '#swagger-ui' });
  </script>
</body>
</html>`);
}

function openApiDocument() {
  return {
    openapi: '3.0.3',
    info: {
      title: 'Практическая работа №4. Реестр плагинов',
      version: '1.0.0',
      description: 'Плагинная система с проверкой зависимостей, детерминированным порядком запуска и диагностикой ошибок.'
    },
    servers: [{ url: 'http://localhost:3004' }],
    paths: {
      '/api/plugins': {
        get: {
          summary: 'Получить состояние реестра плагинов',
          responses: { 200: { description: 'Список плагинов, порядок запуска и лог инициализации' } }
        }
      },
      '/api/plugins/order': {
        get: {
          summary: 'Получить только порядок запуска плагинов',
          responses: { 200: { description: 'Детерминированный порядок запуска' } }
        }
      },
      '/health': {
        get: {
          summary: 'Проверка живости сервиса',
          responses: { 200: { description: 'Сервис работает' } }
        }
      }
    }
  };
}

function createRegistry(configPath) {
  const registry = new PluginRegistry({
    configPath: path.resolve(configPath),
    modulesDir: path.resolve('modules')
  });
  const order = registry.start();
  return { registry, order };
}

function createServer(configPath = 'config/plugins.good.json') {
  const state = createRegistry(configPath);

  return http.createServer((req, res) => {
    const url = new URL(req.url, 'http://localhost');

    if (url.pathname === '/swagger') return sendSwaggerUi(res);
    if (url.pathname === '/openapi.json') return json(res, 200, openApiDocument());
    if (url.pathname === '/health') return json(res, 200, { status: 'ok' });

    if (url.pathname === '/' || url.pathname === '/api/plugins') {
      return json(res, 200, {
        service: 'Практическая работа №4. Реестр плагинов',
        startupOrder: state.order,
        startedPlugins: state.registry.started,
        contextLog: state.registry.context.log
      });
    }

    if (url.pathname === '/api/plugins/order') {
      return json(res, 200, { startupOrder: state.order });
    }

    return json(res, 404, { errorCode: 'NOT_FOUND', message: 'Маршрут не найден.' });
  });
}

if (require.main === module) {
  const configArg = process.argv[2] || 'config/plugins.good.json';
  const port = Number(process.env.PORT || 3004);

  try {
    createServer(configArg).listen(port, () => {
      console.log(`Task 4 plugin registry demo is running: http://localhost:${port}/api/plugins`);
      console.log(`Swagger UI: http://localhost:${port}/swagger`);
    });
  } catch (error) {
    console.error('Plugin system startup failed.');
    console.error(error.message);
    process.exit(1);
  }
}

module.exports = { createServer };
