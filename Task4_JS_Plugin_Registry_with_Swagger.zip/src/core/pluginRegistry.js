const fs = require('fs');
const path = require('path');

function loadPlugin(pluginName, modulesDir) {
  const pluginPath = path.join(modulesDir, pluginName, 'index.js');
  if (!fs.existsSync(pluginPath)) {
    throw new Error(`Plugin '${pluginName}' is listed in config but file was not found: ${pluginPath}`);
  }
  const plugin = require(pluginPath);
  if (!plugin.name || !Array.isArray(plugin.requires) || typeof plugin.init !== 'function') {
    throw new Error(`Plugin '${pluginName}' does not match contract: name, requires[], init(context) are required`);
  }
  return plugin;
}

function sortPlugins(plugins) {
  const byName = new Map(plugins.map(p => [p.name, p]));
  for (const p of plugins) {
    for (const dep of p.requires) {
      if (!byName.has(dep)) {
        throw new Error(`Plugin '${p.name}' requires missing plugin '${dep}'`);
      }
    }
  }
  const result = [];
  const state = new Map();
  const stack = [];
  function visit(p) {
    const s = state.get(p.name);
    if (s === 'done') return;
    if (s === 'visiting') {
      const cycleStart = stack.indexOf(p.name);
      const cycle = [...stack.slice(cycleStart), p.name].join(' -> ');
      throw new Error(`Cyclic plugin dependency detected: ${cycle}`);
    }
    state.set(p.name, 'visiting');
    stack.push(p.name);
    for (const dep of p.requires) visit(byName.get(dep));
    stack.pop();
    state.set(p.name, 'done');
    result.push(p);
  }
  for (const p of plugins) visit(p);
  return result;
}

class PluginRegistry {
  constructor({ configPath, modulesDir }) {
    this.configPath = configPath;
    this.modulesDir = modulesDir;
    this.started = [];
    this.context = { log: [], services: new Map() };
  }

  loadConfig() {
    const config = JSON.parse(fs.readFileSync(this.configPath, 'utf8'));
    if (!Array.isArray(config.plugins)) throw new Error('Config must contain plugins[]');
    return config.plugins;
  }

  start() {
    const names = this.loadConfig();
    const plugins = names.map(name => loadPlugin(name, this.modulesDir));
    const ordered = sortPlugins(plugins);
    for (const plugin of ordered) {
      plugin.init(this.context);
      this.started.push(plugin.name);
      this.context.log.push(`started:${plugin.name}`);
    }
    return this.started;
  }
}

module.exports = { PluginRegistry, sortPlugins };
