const path = require('path');
const { PluginRegistry } = require('./core/pluginRegistry');

const configArg = process.argv[2] || 'config/plugins.good.json';
const registry = new PluginRegistry({
  configPath: path.resolve(configArg),
  modulesDir: path.resolve('modules')
});

try {
  const order = registry.start();
  console.log('Plugins started in deterministic order:');
  console.log(order.join(' -> '));
  console.log('Context log:');
  console.log(registry.context.log.join('\n'));
} catch (error) {
  console.error('Plugin system startup failed.');
  console.error(error.message);
  process.exitCode = 1;
}
