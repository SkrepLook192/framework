module.exports = { name: 'cycle-a', requires: ['cycle-b'], init(context) { context.log.push('cycle-a'); } };
