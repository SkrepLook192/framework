module.exports = {
  name: 'core-plugin',
  requires: [],
  init(context) {
    context.services.set('clock', () => new Date().toISOString());
    context.log.push('core plugin initialized clock service');
  }
};
