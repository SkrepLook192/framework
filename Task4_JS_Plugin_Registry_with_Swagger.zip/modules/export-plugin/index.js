module.exports = {
  name: 'export-plugin',
  requires: ['report-plugin'],
  init(context) {
    const report = context.services.get('report')();
    context.services.set('export', () => JSON.stringify(report));
    context.log.push('export plugin initialized export service');
  }
};
