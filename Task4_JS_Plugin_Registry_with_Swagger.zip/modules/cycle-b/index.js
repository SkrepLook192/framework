module.exports = { name: 'cycle-b', requires: ['cycle-a'], init(context) { context.log.push('cycle-b'); } };
