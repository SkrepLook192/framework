module.exports = {
  name: 'audit-plugin',
  requires: ['core-plugin'],
  init(context) {
    const clock = context.services.get('clock');
    context.services.set('audit', (message) => `AUDIT ${clock()}: ${message}`);
    context.log.push('audit plugin initialized audit service');
  }
};
