module.exports = {
  name: 'report-plugin',
  requires: ['core-plugin', 'audit-plugin'],
  init(context) {
    const audit = context.services.get('audit');
    context.services.set('report', () => ({ title: 'Demo report', rows: 3 }));
    context.log.push(audit('report plugin created report service'));
  }
};
