const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const { PluginRegistry, sortPlugins } = require('../src/core/pluginRegistry');

test('sorts plugins according to dependencies', () => {
  const plugins = [
    { name: 'c', requires: ['b'], init() {} },
    { name: 'a', requires: [], init() {} },
    { name: 'b', requires: ['a'], init() {} }
  ];
  assert.deepEqual(sortPlugins(plugins).map(x => x.name), ['a', 'b', 'c']);
});

test('reports missing dependency with clear message', () => {
  const plugins = [
    { name: 'report', requires: ['audit'], init() {} }
  ];
  assert.throws(() => sortPlugins(plugins), /requires missing plugin 'audit'/);
});

test('reports cycle with clear message', () => {
  const plugins = [
    { name: 'a', requires: ['b'], init() {} },
    { name: 'b', requires: ['a'], init() {} }
  ];
  assert.throws(() => sortPlugins(plugins), /Cyclic plugin dependency detected/);
});

test('registry initializes real plugins in deterministic order', () => {
  const root = path.resolve(__dirname, '..');
  const registry = new PluginRegistry({
    configPath: path.join(root, 'config/plugins.good.json'),
    modulesDir: path.join(root, 'modules')
  });
  const order = registry.start();
  assert.deepEqual(order, ['core-plugin', 'audit-plugin', 'report-plugin', 'export-plugin']);
  assert.equal(typeof registry.context.services.get('export'), 'function');
});
