module.exports = { name: 'a', requires: [], register() {}, init() {} };
