module.exports = { name: 'b', requires: ['a'], register() {}, init() {} };
