module.exports = { name: 'c', requires: ['b'], register() {}, init() {} };
