module.exports = {
  name: 'module-b',
  requires: ['module-a'],
  register() {},
  init() {}
};
