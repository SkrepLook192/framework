module.exports = {
  name: 'module-a',
  requires: ['module-b'],
  register() {},
  init() {}
};
