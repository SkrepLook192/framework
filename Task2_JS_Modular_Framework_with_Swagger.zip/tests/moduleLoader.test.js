const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { Container } = require('../src/core/container');
const {
  loadModules,
  buildStartupOrder,
  registerModules,
  initializeModules
} = require('../src/core/moduleLoader');

test('строит корректный порядок запуска модулей по зависимостям', () => {
  const modules = loadModules({
    modulesDirectory: 'tests/fixtures/simple-modules',
    enabledModules: ['c', 'a', 'b']
  });

  const order = buildStartupOrder(modules).map(module => module.name);

  assert.deepEqual(order, ['a', 'b', 'c']);
});

test('выдаёт понятную ошибку, если модуль отсутствует', () => {
  assert.throws(
    () => loadModules({
      modulesDirectory: 'tests/fixtures/simple-modules',
      enabledModules: ['a', 'missing-module']
    }),
    /Модуль 'missing-module' не найден/
  );
});

test('выдаёт понятную ошибку при циклических зависимостях', () => {
  const modules = loadModules({
    modulesDirectory: 'tests/fixtures/cycle-modules',
    enabledModules: ['module-a', 'module-b']
  });

  assert.throws(
    () => buildStartupOrder(modules),
    /Обнаружен цикл зависимостей модулей: module-a -> module-b -> module-a/
  );
});

test('модули получают зависимости через DI-контейнер', async () => {
  const modules = loadModules({
    modulesDirectory: 'modules',
    enabledModules: ['data-module', 'validation-module', 'report-module']
  });

  const order = buildStartupOrder(modules);
  const container = new Container();
  const fakeLogger = { log() {} };

  registerModules(order, container, fakeLogger);
  await initializeModules(order, container, fakeLogger);

  const taskStore = container.resolve('taskStore');
  const reportService = container.resolve('reportService');
  const report = reportService.buildReport();

  assert.equal(container.resolve('taskStore'), taskStore);
  assert.equal(report.tasksCount, taskStore.getAll().length);
  assert.ok(container.has('validationService'));
});
