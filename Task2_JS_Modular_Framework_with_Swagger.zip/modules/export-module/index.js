const fs = require('fs');
const path = require('path');

class ExportService {
  constructor(reportService) {
    this.reportService = reportService;
  }

  exportReport(filePath) {
    const report = this.reportService.buildReport();
    const fullPath = path.resolve(filePath);
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });
    fs.writeFileSync(fullPath, JSON.stringify(report, null, 2), 'utf-8');
    return fullPath;
  }
}

module.exports = {
  name: 'export-module',
  requires: ['report-module'],

  register(container) {
    container.registerTransient('exportService', c => {
      return new ExportService(c.resolve('reportService'));
    });
  },

  init(container) {
    const exportService = container.resolve('exportService');
    const filePath = exportService.exportReport('output/report.json');
    console.log(`[export-module] Отчёт экспортирован в файл: ${filePath}`);
  }
};
