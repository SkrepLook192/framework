class ReportService {
  constructor(taskStore) {
    this.taskStore = taskStore;
  }

  buildReport() {
    const tasks = this.taskStore.getAll();
    const totalHours = tasks.reduce((sum, task) => sum + task.estimatedHours, 0);

    return {
      generatedAt: new Date().toISOString(),
      tasksCount: tasks.length,
      totalEstimatedHours: totalHours,
      tasksBySubject: tasks.reduce((acc, task) => {
        acc[task.subject] = (acc[task.subject] || 0) + 1;
        return acc;
      }, {})
    };
  }
}

module.exports = {
  name: 'report-module',
  requires: ['data-module'],

  register(container) {
    container.registerSingleton('reportService', c => {
      return new ReportService(c.resolve('taskStore'));
    });
  },

  init(container) {
    const reportService = container.resolve('reportService');
    const report = reportService.buildReport();
    console.log(`[report-module] Отчёт готов. Задач: ${report.tasksCount}, часов: ${report.totalEstimatedHours}`);
  }
};
