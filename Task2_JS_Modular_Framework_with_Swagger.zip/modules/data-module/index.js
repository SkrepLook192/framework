class TaskStore {
  constructor() {
    this.nextId = 1;
    this.tasks = [];
  }

  seed() {
    if (this.tasks.length > 0) {
      return;
    }

    this.create({ title: 'Изучить модульную архитектуру', subject: 'Фреймворки', estimatedHours: 2 });
    this.create({ title: 'Подготовить демонстрацию DI', subject: 'JavaScript', estimatedHours: 3 });
  }

  getAll() {
    return [...this.tasks];
  }

  getById(id) {
    return this.tasks.find(task => task.id === Number(id)) || null;
  }

  create(data) {
    const task = {
      id: this.nextId++,
      title: String(data.title).trim(),
      subject: String(data.subject || '').trim(),
      estimatedHours: Number(data.estimatedHours),
      createdAt: new Date().toISOString()
    };

    this.tasks.push(task);
    return task;
  }
}

module.exports = {
  name: 'data-module',
  requires: [],

  register(container) {
    container.registerSingleton('taskStore', () => new TaskStore());
  },

  init(container) {
    const store = container.resolve('taskStore');
    store.seed();
    console.log(`[data-module] Загружено начальных задач: ${store.getAll().length}`);
  }
};
