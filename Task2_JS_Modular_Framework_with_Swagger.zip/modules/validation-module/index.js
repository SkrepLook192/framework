class ValidationService {
  validateTask(input) {
    const errors = [];

    if (!input || typeof input !== 'object') {
      errors.push('Тело запроса должно быть JSON-объектом.');
      return errors;
    }

    if (!input.title || String(input.title).trim().length === 0) {
      errors.push('Название задачи не должно быть пустым.');
    }

    if (String(input.title || '').length > 100) {
      errors.push('Название задачи не должно быть длиннее 100 символов.');
    }

    if (input.estimatedHours === undefined || Number.isNaN(Number(input.estimatedHours))) {
      errors.push('Количество часов должно быть числом.');
    } else if (Number(input.estimatedHours) < 0) {
      errors.push('Количество часов не может быть отрицательным.');
    }

    return errors;
  }
}

module.exports = {
  name: 'validation-module',
  requires: [],

  register(container) {
    container.registerSingleton('validationService', () => new ValidationService());
  },

  init() {
    console.log('[validation-module] Правила проверки данных подключены.');
  }
};
