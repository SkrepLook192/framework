class Container {
  constructor() {
    this.registrations = new Map();
    this.singletons = new Map();
  }

  registerValue(name, value) {
    this.registrations.set(name, { lifetime: 'value', value });
  }

  registerSingleton(name, factory) {
    this.registrations.set(name, { lifetime: 'singleton', factory });
  }

  registerTransient(name, factory) {
    this.registrations.set(name, { lifetime: 'transient', factory });
  }

  has(name) {
    return this.registrations.has(name);
  }

  resolve(name) {
    const registration = this.registrations.get(name);

    if (!registration) {
      throw new Error(`Служба '${name}' не зарегистрирована в DI-контейнере.`);
    }

    if (registration.lifetime === 'value') {
      return registration.value;
    }

    if (registration.lifetime === 'singleton') {
      if (!this.singletons.has(name)) {
        this.singletons.set(name, registration.factory(this));
      }

      return this.singletons.get(name);
    }

    if (registration.lifetime === 'transient') {
      return registration.factory(this);
    }

    throw new Error(`Неизвестное время жизни службы '${name}'.`);
  }
}

module.exports = { Container };
