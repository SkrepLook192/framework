const fs = require('fs');
const path = require('path');

function readModuleConfig(configPath) {
  const fullPath = path.resolve(configPath);
  const raw = fs.readFileSync(fullPath, 'utf-8');
  const config = JSON.parse(raw);

  if (!Array.isArray(config.enabledModules)) {
    throw new Error('В файле настроек поле enabledModules должно быть массивом.');
  }

  return {
    modulesDirectory: config.modulesDirectory || 'modules',
    enabledModules: config.enabledModules
  };
}

function loadModules(config) {
  const modulesDir = path.resolve(config.modulesDirectory);
  const modules = new Map();

  for (const moduleName of config.enabledModules) {
    const modulePath = path.join(modulesDir, moduleName, 'index.js');

    if (!fs.existsSync(modulePath)) {
      throw new Error(`Модуль '${moduleName}' не найден. Ожидался файл: ${modulePath}`);
    }

    const moduleInstance = require(modulePath);
    validateModuleContract(moduleInstance, moduleName);
    modules.set(moduleInstance.name, moduleInstance);
  }

  for (const moduleInstance of modules.values()) {
    for (const dependency of moduleInstance.requires) {
      if (!modules.has(dependency)) {
        throw new Error(
          `Модулю '${moduleInstance.name}' требуется модуль '${dependency}', но он не подключён в настройках.`
        );
      }
    }
  }

  return modules;
}

function validateModuleContract(moduleInstance, expectedFolderName) {
  if (!moduleInstance || typeof moduleInstance !== 'object') {
    throw new Error(`Модуль '${expectedFolderName}' должен экспортировать объект.`);
  }

  if (typeof moduleInstance.name !== 'string' || moduleInstance.name.trim() === '') {
    throw new Error(`Модуль '${expectedFolderName}' не содержит корректное поле name.`);
  }

  if (!Array.isArray(moduleInstance.requires)) {
    throw new Error(`Модуль '${moduleInstance.name}' должен содержать массив requires.`);
  }

  if (typeof moduleInstance.register !== 'function') {
    throw new Error(`Модуль '${moduleInstance.name}' должен содержать метод register(container).`);
  }

  if (typeof moduleInstance.init !== 'function') {
    throw new Error(`Модуль '${moduleInstance.name}' должен содержать метод init(container).`);
  }
}

function buildStartupOrder(modules) {
  const ordered = [];
  const state = new Map();
  const stack = [];

  function visit(moduleName) {
    const currentState = state.get(moduleName);

    if (currentState === 'visiting') {
      const cycleStart = stack.indexOf(moduleName);
      const cycle = stack.slice(cycleStart).concat(moduleName).join(' -> ');
      throw new Error(`Обнаружен цикл зависимостей модулей: ${cycle}`);
    }

    if (currentState === 'visited') {
      return;
    }

    const moduleInstance = modules.get(moduleName);

    if (!moduleInstance) {
      throw new Error(`Модуль '${moduleName}' не найден при построении порядка запуска.`);
    }

    state.set(moduleName, 'visiting');
    stack.push(moduleName);

    for (const dependency of moduleInstance.requires) {
      visit(dependency);
    }

    stack.pop();
    state.set(moduleName, 'visited');
    ordered.push(moduleInstance);
  }

  for (const moduleName of modules.keys()) {
    visit(moduleName);
  }

  return ordered;
}

function registerModules(modulesInOrder, container, logger = console) {
  for (const moduleInstance of modulesInOrder) {
    logger.log(`[register] ${moduleInstance.name}`);
    moduleInstance.register(container);
  }
}

async function initializeModules(modulesInOrder, container, logger = console) {
  for (const moduleInstance of modulesInOrder) {
    logger.log(`[init] ${moduleInstance.name}`);
    await moduleInstance.init(container);
  }
}

module.exports = {
  readModuleConfig,
  loadModules,
  validateModuleContract,
  buildStartupOrder,
  registerModules,
  initializeModules
};
