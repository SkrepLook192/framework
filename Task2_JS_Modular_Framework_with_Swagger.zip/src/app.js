const http = require('http');
const crypto = require('crypto');
const { Container } = require('./core/container');
const { readJsonBody, sendJson } = require('./core/jsonBody');
const { sendSwaggerUi, sendOpenApi } = require('./core/swagger');
const {
  readModuleConfig,
  loadModules,
  buildStartupOrder,
  registerModules,
  initializeModules
} = require('./core/moduleLoader');


function buildOpenApiDocument(modulesInOrder) {
  return {
    openapi: '3.0.3',
    info: {
      title: 'Практическая работа №2. Модульное приложение',
      version: '1.0.0',
      description: 'Node.js-приложение с модулями, DI-контейнером и запуском модулей по зависимостям.'
    },
    servers: [{ url: 'http://localhost:3000' }],
    paths: {
      '/api/modules': {
        get: {
          summary: 'Получить список загруженных модулей',
          responses: {
            200: { description: 'Модули запущены в корректном порядке' }
          }
        }
      },
      '/api/tasks': {
        get: {
          summary: 'Получить список учебных задач',
          responses: { 200: { description: 'Список задач' } }
        },
        post: {
          summary: 'Создать новую учебную задачу',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: { $ref: '#/components/schemas/CreateTaskRequest' },
                example: {
                  title: 'Сделать практическую работу',
                  subject: 'Фреймворки',
                  estimatedHours: 4
                }
              }
            }
          },
          responses: {
            201: { description: 'Задача создана' },
            400: { description: 'Ошибка валидации' }
          }
        }
      },
      '/api/report': {
        get: {
          summary: 'Получить отчёт, сформированный модулем report-module',
          responses: { 200: { description: 'Отчёт по задачам' } }
        }
      }
    },
    components: {
      schemas: {
        CreateTaskRequest: {
          type: 'object',
          required: ['title', 'subject', 'estimatedHours'],
          properties: {
            title: { type: 'string', example: 'Сделать практическую работу' },
            subject: { type: 'string', example: 'Фреймворки' },
            estimatedHours: { type: 'number', example: 4 }
          }
        },
        ErrorResponse: {
          type: 'object',
          properties: {
            errorCode: { type: 'string' },
            message: { type: 'string' },
            requestId: { type: 'string' }
          }
        }
      }
    },
    'x-loaded-modules': modulesInOrder.map(module => module.name)
  };
}

async function bootstrap() {
  const configPath = process.env.MODULE_CONFIG || 'config/modules.json';
  const port = Number(process.env.PORT || 3000);

  const container = new Container();
  container.registerValue('appConfig', { port });

  const config = readModuleConfig(configPath);
  const modules = loadModules(config);
  const modulesInOrder = buildStartupOrder(modules);

  console.log('Порядок запуска модулей:', modulesInOrder.map(module => module.name).join(' -> '));

  registerModules(modulesInOrder, container);
  await initializeModules(modulesInOrder, container);

  const server = http.createServer((req, res) => handleRequest(req, res, container, modulesInOrder));

  server.listen(port, () => {
    console.log(`Приложение запущено: http://localhost:${port}`);
    console.log(`Swagger UI: http://localhost:${port}/swagger`);
    console.log('Доступные запросы:');
    console.log('GET  /api/modules');
    console.log('GET  /api/tasks');
    console.log('GET  /api/report');
    console.log('POST /api/tasks');
    console.log('GET  /swagger');
  });
}

async function handleRequest(req, res, container, modulesInOrder) {
  const requestId = crypto.randomUUID();
  const startedAt = Date.now();

  try {
    console.log(`[request] requestId=${requestId} method=${req.method} url=${req.url}`);

    const url = new URL(req.url, 'http://localhost');


    if (req.method === 'GET' && url.pathname === '/swagger') {
      return sendSwaggerUi(res, 'Практическая работа №2 — Swagger');
    }

    if (req.method === 'GET' && url.pathname === '/openapi.json') {
      return sendOpenApi(res, buildOpenApiDocument(modulesInOrder));
    }

    if (req.method === 'GET' && url.pathname === '/') {
      return sendJson(res, 200, {
        service: 'Практическая работа №2. Модульное приложение на JavaScript',
        modules: modulesInOrder.map(module => module.name),
        endpoints: ['GET /api/modules', 'GET /api/tasks', 'GET /api/report', 'POST /api/tasks']
      });
    }

    if (req.method === 'GET' && url.pathname === '/api/modules') {
      return sendJson(res, 200, modulesInOrder.map(module => ({
        name: module.name,
        requires: module.requires
      })));
    }

    if (req.method === 'GET' && url.pathname === '/api/tasks') {
      const taskStore = container.resolve('taskStore');
      return sendJson(res, 200, taskStore.getAll());
    }

    if (req.method === 'GET' && url.pathname === '/api/report') {
      const reportService = container.resolve('reportService');
      return sendJson(res, 200, reportService.buildReport());
    }

    if (req.method === 'POST' && url.pathname === '/api/tasks') {
      const input = await readJsonBody(req);
      const validationService = container.resolve('validationService');
      const errors = validationService.validateTask(input);

      if (errors.length > 0) {
        return sendJson(res, 400, {
          errorCode: 'VALIDATION_ERROR',
          message: 'Переданы некорректные данные.',
          details: errors,
          requestId
        });
      }

      const taskStore = container.resolve('taskStore');
      const createdTask = taskStore.create(input);
      return sendJson(res, 201, createdTask);
    }

    return sendJson(res, 404, {
      errorCode: 'NOT_FOUND',
      message: 'Маршрут не найден.',
      requestId
    });
  } catch (error) {
    return sendJson(res, 500, {
      errorCode: 'INTERNAL_ERROR',
      message: error.message,
      requestId
    });
  } finally {
    const elapsedMs = Date.now() - startedAt;
    console.log(`[response] requestId=${requestId} elapsedMs=${elapsedMs}`);
  }
}

bootstrap().catch(error => {
  console.error('Приложение не запущено:', error.message);
  process.exit(1);
});
