using System.Net;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Mvc.Testing;
using Pr1.MinWebService.Domain;

namespace Pr1.MinWebService.Tests;

public class ItemApiTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;

    public ItemApiTests(WebApplicationFactory<Program> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetItems_ReturnsList()
    {
        var response = await _client.GetAsync("/api/items");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var items = await response.Content.ReadFromJsonAsync<Item[]>();
        Assert.NotNull(items);
        Assert.NotEmpty(items!);
    }

    [Fact]
    public async Task CreateItem_ThenGetById_ReturnsCreatedItem()
    {
        var request = new CreateItemRequest("Написать интеграционный тест", "Тестирование", 2);

        var createResponse = await _client.PostAsJsonAsync("/api/items", request);

        Assert.Equal(HttpStatusCode.Created, createResponse.StatusCode);
        Assert.True(createResponse.Headers.Contains("X-Request-Id"));

        var created = await createResponse.Content.ReadFromJsonAsync<Item>();
        Assert.NotNull(created);
        Assert.NotEqual(Guid.Empty, created!.Id);

        var getResponse = await _client.GetAsync($"/api/items/{created.Id}");

        Assert.Equal(HttpStatusCode.OK, getResponse.StatusCode);

        var loaded = await getResponse.Content.ReadFromJsonAsync<Item>();
        Assert.NotNull(loaded);
        Assert.Equal(request.Name, loaded!.Name);
        Assert.Equal(request.Subject, loaded.Subject);
    }

    [Fact]
    public async Task GetUnknownItem_ReturnsUnifiedError()
    {
        var unknownId = Guid.NewGuid();

        var response = await _client.GetAsync($"/api/items/{unknownId}");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);

        var error = await response.Content.ReadFromJsonAsync<ErrorResponse>();
        Assert.NotNull(error);
        Assert.Equal("item_not_found", error!.Code);
        Assert.False(string.IsNullOrWhiteSpace(error.RequestId));
    }

    [Fact]
    public async Task CreateItem_WithInvalidData_ReturnsUnifiedValidationError()
    {
        var request = new CreateItemRequest("", "C#", -1);

        var response = await _client.PostAsJsonAsync("/api/items", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);

        var error = await response.Content.ReadFromJsonAsync<ErrorResponse>();
        Assert.NotNull(error);
        Assert.Equal("validation_error", error!.Code);
        Assert.False(string.IsNullOrWhiteSpace(error.RequestId));
    }

    [Fact]
    public async Task CustomRequestId_IsReturnedInHeaderAndErrorBody()
    {
        var requestId = "student-test-1";
        using var request = new HttpRequestMessage(HttpMethod.Get, $"/api/items/{Guid.NewGuid()}");
        request.Headers.Add("X-Request-Id", requestId);

        var response = await _client.SendAsync(request);

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        Assert.True(response.Headers.TryGetValues("X-Request-Id", out var headerValues));
        Assert.Contains(requestId, headerValues);

        var error = await response.Content.ReadFromJsonAsync<ErrorResponse>();
        Assert.NotNull(error);
        Assert.Equal(requestId, error!.RequestId);
    }
}
