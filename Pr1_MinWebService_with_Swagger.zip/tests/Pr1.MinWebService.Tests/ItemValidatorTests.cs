using Pr1.MinWebService.Domain;
using Pr1.MinWebService.Errors;

namespace Pr1.MinWebService.Tests;

public class ItemValidatorTests
{
    [Fact]
    public void ValidateForCreate_WithCorrectData_DoesNotThrow()
    {
        var request = new CreateItemRequest("Сделать практическую", "C#", 3);

        var exception = Record.Exception(() => ItemValidator.ValidateForCreate(request));

        Assert.Null(exception);
    }

    [Fact]
    public void ValidateForCreate_WithEmptyName_ThrowsValidationException()
    {
        var request = new CreateItemRequest("   ", "C#", 3);

        Assert.Throws<ValidationException>(() => ItemValidator.ValidateForCreate(request));
    }

    [Fact]
    public void ValidateForCreate_WithNegativeHours_ThrowsValidationException()
    {
        var request = new CreateItemRequest("Сделать практическую", "C#", -1);

        Assert.Throws<ValidationException>(() => ItemValidator.ValidateForCreate(request));
    }
}
