namespace Pr1.MinWebService.Errors;

public sealed class NotFoundException : DomainException
{
    public NotFoundException(string message)
        : base(code: "item_not_found", message: message, statusCode: StatusCodes.Status404NotFound)
    {
    }
}
