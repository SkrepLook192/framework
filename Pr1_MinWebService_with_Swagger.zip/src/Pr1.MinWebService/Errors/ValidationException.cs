namespace Pr1.MinWebService.Errors;

public sealed class ValidationException : DomainException
{
    public ValidationException(string message)
        : base(code: "validation_error", message: message, statusCode: StatusCodes.Status400BadRequest)
    {
    }
}
