using Pr1.MinWebService.Services;

namespace Pr1.MinWebService.Middlewares;

/// <summary>
/// Пишет в журнал входящий запрос и исходящий ответ.
/// </summary>
public sealed class RequestLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<RequestLoggingMiddleware> _logger;

    public RequestLoggingMiddleware(RequestDelegate next, ILogger<RequestLoggingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task Invoke(HttpContext context)
    {
        var requestId = RequestId.GetOrCreate(context);

        _logger.LogInformation(
            "Входящий запрос. requestId={RequestId} method={Method} path={Path} query={Query}",
            requestId,
            context.Request.Method,
            context.Request.Path.Value ?? string.Empty,
            context.Request.QueryString.Value ?? string.Empty);

        await _next(context);

        _logger.LogInformation(
            "Исходящий ответ. requestId={RequestId} status={StatusCode}",
            requestId,
            context.Response.StatusCode);
    }
}
