using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Http.Json;
using Pr1.MinWebService.Domain;
using Pr1.MinWebService.Errors;
using Pr1.MinWebService.Middlewares;
using Pr1.MinWebService.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<JsonOptions>(options =>
{
    options.SerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<IItemRepository, InMemoryItemRepository>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "Практическая работа №1 API v1");
        options.RoutePrefix = "swagger";
    });
}

// Конвейер обработки запроса.
app.UseMiddleware<RequestIdMiddleware>();
app.UseMiddleware<RequestLoggingMiddleware>();
app.UseMiddleware<ErrorHandlingMiddleware>();
app.UseMiddleware<PerformanceMiddleware>();

app.MapGet("/", () => Results.Redirect("/swagger"))
    .ExcludeFromDescription();

// GET /api/items?subject=C%23&sort=hours
app.MapGet("/api/items", (IItemRepository repo, string? subject, string? sort) =>
{
    var items = repo.GetAll().AsEnumerable();

    if (!string.IsNullOrWhiteSpace(subject))
    {
        items = items.Where(x =>
            x.Subject.Contains(subject.Trim(), StringComparison.OrdinalIgnoreCase));
    }

    items = sort?.Trim().ToLowerInvariant() switch
    {
        "name" => items.OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase),
        "subject" => items.OrderBy(x => x.Subject, StringComparer.OrdinalIgnoreCase),
        "hours" => items.OrderBy(x => x.EstimatedHours),
        "created" => items.OrderBy(x => x.CreatedAtUtc),
        _ => items.OrderBy(x => x.CreatedAtUtc)
    };

    return Results.Ok(items);
})
.WithName("GetItems");

app.MapGet("/api/items/{id:guid}", (Guid id, IItemRepository repo) =>
{
    var item = repo.GetById(id);

    if (item is null)
        throw new NotFoundException($"Элемент с идентификатором {id} не найден");

    return Results.Ok(item);
})
.WithName("GetItemById");

app.MapPost("/api/items", (HttpContext ctx, CreateItemRequest request, IItemRepository repo) =>
{
    var created = repo.Create(request);

    var location = $"/api/items/{created.Id}";
    ctx.Response.Headers.Location = location;

    return Results.Created(location, created);
})
.WithName("CreateItem");

app.Run();

// Нужен для интеграционных тестов через WebApplicationFactory.
public partial class Program { }
