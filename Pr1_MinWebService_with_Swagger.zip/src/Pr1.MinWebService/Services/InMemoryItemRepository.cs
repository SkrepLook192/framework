using System.Collections.Concurrent;
using Pr1.MinWebService.Domain;

namespace Pr1.MinWebService.Services;

/// <summary>
/// Простое потокобезопасное хранилище в памяти процесса.
/// </summary>
public sealed class InMemoryItemRepository : IItemRepository
{
    private readonly ConcurrentDictionary<Guid, Item> _items = new();

    public InMemoryItemRepository()
    {
        Create(new CreateItemRequest("Изучить middleware ASP.NET Core", "C#", 2));
        Create(new CreateItemRequest("Подготовить отчёт по практической работе", "Фреймворки", 3));
        Create(new CreateItemRequest("Написать проверки для API", "Тестирование", 1));
    }

    public IReadOnlyCollection<Item> GetAll()
        => _items.Values
            .OrderBy(x => x.CreatedAtUtc)
            .ToArray();

    public Item? GetById(Guid id)
        => _items.TryGetValue(id, out var item) ? item : null;

    public Item Create(CreateItemRequest request)
    {
        ItemValidator.ValidateForCreate(request);

        var item = new Item(
            Guid.NewGuid(),
            request.Name.Trim(),
            request.Subject.Trim(),
            request.EstimatedHours,
            IsCompleted: false,
            DateTime.UtcNow);

        _items[item.Id] = item;
        return item;
    }
}
