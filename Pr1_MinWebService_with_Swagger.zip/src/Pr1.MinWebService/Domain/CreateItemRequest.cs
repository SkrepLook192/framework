namespace Pr1.MinWebService.Domain;

/// <summary>
/// Входная модель для создания учебной задачи.
/// </summary>
public sealed record CreateItemRequest(
    string Name,
    string Subject,
    int EstimatedHours
);
