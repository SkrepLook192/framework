namespace Pr1.MinWebService.Domain;

/// <summary>
/// Элемент предметной области: учебная задача.
/// </summary>
public sealed record Item(
    Guid Id,
    string Name,
    string Subject,
    int EstimatedHours,
    bool IsCompleted,
    DateTime CreatedAtUtc
);
