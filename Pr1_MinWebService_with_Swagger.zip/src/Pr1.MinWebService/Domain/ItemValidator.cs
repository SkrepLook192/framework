using Pr1.MinWebService.Errors;

namespace Pr1.MinWebService.Domain;

/// <summary>
/// Правила предметной области для учебной задачи.
/// </summary>
public static class ItemValidator
{
    public static void ValidateForCreate(CreateItemRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Name))
            throw new ValidationException("Поле name не должно быть пустым");

        if (request.Name.Trim().Length > 100)
            throw new ValidationException("Поле name не должно быть длиннее 100 символов");

        if (string.IsNullOrWhiteSpace(request.Subject))
            throw new ValidationException("Поле subject не должно быть пустым");

        if (request.Subject.Trim().Length > 60)
            throw new ValidationException("Поле subject не должно быть длиннее 60 символов");

        if (request.EstimatedHours < 0)
            throw new ValidationException("Поле estimatedHours не может быть отрицательным");

        if (request.EstimatedHours > 1000)
            throw new ValidationException("Поле estimatedHours не должно быть больше 1000");
    }
}
